# TPM Real Install Health Check

Run ID: 3f55ee49110b4f6b95f550a4a8ef7c34
Status: **PASS**
TeknoParrot root: C:\Users\EliSi\LaunchBox\Emulators\TeknoParrot

## Checks
- [PASS] TeknoParrotUi.exe exists: C:\Users\EliSi\LaunchBox\Emulators\TeknoParrot\TeknoParrotUi.exe
- [PASS] GameProfiles folder exists: C:\Users\EliSi\LaunchBox\Emulators\TeknoParrot\GameProfiles
- [PASS] UserProfiles folder exists: C:\Users\EliSi\LaunchBox\Emulators\TeknoParrot\UserProfiles
- [PASS] pcsx2x6 crosshair folder exists: C:\Users\EliSi\LaunchBox\Emulators\TeknoParrot\pcsx2x6\TeknoParrot\crosshairs
- [PASS] GameProfiles XML parse: files=552 invalid=0
- [PASS] UserProfiles XML parse: files=54 invalid=0
- [PASS] No duplicate GameProfiles filenames: duplicates=0

## Artifacts
- JSON: E:\REPOS\TPM-TestHarness\Reports\2026-08-31_10-44-55\InstallHealth\InstallHealth.json
- Log: E:\REPOS\TPM-TestHarness\Reports\2026-08-31_10-44-55\InstallHealth\InstallHealth.log
